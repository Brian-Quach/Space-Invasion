let searchStr = window.location.search
let user1pos = searchStr.search("user1") + 6

let user1 = ""
char = ''
while (char != '&') {
	user1 += char
	char = user1pos
	user1pos += 1
}

getGamesFromDb(user1).then(function(result) {
	let res = JSON.parse(result)
	if (res.result) {
		// need to start the game
		goToGame()
	} else {
		nameInput.value = ""
		passInput.value = ""
	}
}).catch(function(error) {
	console.log("error getting user from database");
	console.log(error);
})

function getGamesFromDb(username, password) {
	console.log("getting user from database")
	return new Promise(function (resolve, reject) {
        let xmlHttp = new XMLHttpRequest();
        xmlHttp.open("PUT", '/homeGames', true);
        xmlHttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
        xmlHttp.onload = function () {
            if (this.status == 200) {
                resolve(xmlHttp.responseText);
            } else {
                reject({
                    status: this.status,
                    statusText: xmlHttp.statusText
                });
            }
        };
        xmlHttp.onerror = function () {
            reject({
                status: this.status,
                statusText: xmlHttp.statusText
            });
        };
        let body = {"username": username}

        xmlHttp.send(JSON.stringify(body));
    });
}