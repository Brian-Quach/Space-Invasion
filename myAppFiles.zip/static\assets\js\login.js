const firebase = require("firebase");
require("firebase/firestore");

let submitBtn = document.getElementById("submitBtn")
let nameInput = document.getElementById("nameInput")
let passInput = document.getElementById("passInput")

var db = firebase.firestore();

submitBtn.addEventListener("click", function() {
	let name = nameInput.value
	let pass = passInput.value

	db.collection("users").add({
	    first: "Ada",
	    last: "Lovelace",
	    born: 1815
	})
	.then(function(docRef) {
	    console.log("Document written with ID: ", docRef.id);
	})
	.catch(function(error) {
	    console.error("Error adding document: ", error);
	});
})